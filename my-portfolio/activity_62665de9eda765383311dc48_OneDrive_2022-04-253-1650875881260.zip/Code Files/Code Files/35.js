var weekdays = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
];

for(i = 0; i <= 10; i++){
  console.log(i + ". Hello Programmers!");
}

for(i = 0; i > -10; i--){
  console.log(i + ". Hello Programmers! Negative");
}