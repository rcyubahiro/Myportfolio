var weekdays = [
  "Monday",
  "Tuesday",
  "Wednesday",
  "Thursday",
  "Friday",
  "Saturday",
  "Sunday"
];

for(i = 0; i <= 10; i++){
  if(i == 5){
    continue;
  }
  console.log(i + ". Hello Programmers!");
  for(c = 0; c < 10; c++){
    console.log(c + "))) Some sub values");
  }
}