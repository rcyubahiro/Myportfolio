i = 10;
c = 10;
while (i < 10) {
  console.log(i + ". Some text");
  i++;
}

do {
  console.log(c + ". Some text (do while loop)");
  c++;
} while(c < 10);