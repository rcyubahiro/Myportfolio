var person = {
  name: "Shahzaib Kamal",
  eyeColor: "Brown",
  hairColor: "Black",
  age: 27,
  weight: 80,
  nationality: "Pakistani"
}

console.log(
  "The " +
  person.name +
  " has " +
  person.eyeColor +
  "eyes and " +
  person.hairColor +
  " hair"
);