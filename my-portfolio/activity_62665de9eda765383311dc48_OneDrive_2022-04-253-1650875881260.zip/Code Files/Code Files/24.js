function basicMath(value1, value2){
  var sum1 = value1 + value2;
  return sum1;
}

console.log(basicMath(6, 9));
var funcval2 = basicMath(11, 7);
basicMath(8, 67);

console.log(funcval2 + 50);