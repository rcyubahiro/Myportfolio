var var1 = 10;

function func1(){
  var var2 = 20;
  console.log(var1);
  console.log(var2);
}
func1();

console.log(var1);
// console.log(var2);

function func2(){
  var var2 = 20;
  console.log(var1);
  console.log(var2);
}

func2();